﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OracleClient;
using System.Data.SqlClient;
using WebApplication1.App_Data;
using System.Data;

namespace WebApplication1
{
    public partial class Home : System.Web.UI.Page
    {
        DB connection = new DB();
        protected void Page_Load(object sender, EventArgs e)
        {
            ShowData();

        }

        public void ShowData()
        {
            string query = ("select * from employees");

            DataTable dt = new DataTable();

            dt = connection.SelectMTM2(query);

            GridView1.DataSource = dt;
            GridView1.DataBind();

        }
    }
}