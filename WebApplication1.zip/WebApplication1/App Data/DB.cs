﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OracleClient;
using System.Linq;
using System.Web;

namespace WebApplication1.App_Data
{
    public class DB
    {
            private static string connectionStringMTM2 = System.Configuration.ConfigurationManager.ConnectionStrings["AliString"].ConnectionString;

            public OracleConnection con;
            //public bool openDBorcl()
            //{
            //    if (con == null)
            //    {
            //        con = new OracleConnection();
            //        con.ConnectionString = connectionStringORCL;
            //    }
            //    try
            //    {
            //        if (con.State == ConnectionState.Closed)
            //        {
            //            con.Open();
            //            con.Close();
            //        }
            //    }
            //    catch (Exception excep)
            //    {
            //        Console.WriteLine(excep);
            //        return false;
            //    }

            //    return true;
            //}//END
            //public bool openDBmtm2()
            //{
            //    if (con == null)
            //    {
            //        con = new OracleConnection();
            //        con.ConnectionString = connectionStringMTM2;
            //    }
            //    try
            //    {
            //        if (con.State == ConnectionState.Closed)
            //        {
            //            con.Open();
            //            con.Close();
            //        }
            //    }
            //    catch (Exception excep)
            //    {
            //        Console.WriteLine(excep);
            //        return false;
            //    }

            //    return true;
            //}//END

            public DataTable SelectMTM2(string qry)
            {
                DataTable dt = new DataTable();
                try
                {
                    OracleCommand cmd = new OracleCommand();
                    con = new OracleConnection(connectionStringMTM2);
                    cmd.Connection = con;

                    con.Open();
                    cmd.CommandText = qry;
                    OracleDataAdapter da = new OracleDataAdapter(cmd);
                    da.Fill(dt);
                    con.Close();
                }
                catch (Exception ex)
                {
                    //return Ret;                

                }
                return dt;
            }


            public DataTable SelectMTM3(string qry1)
            {
                DataTable dt = new DataTable();
                try
                {
                    OracleCommand cmd = new OracleCommand();
                    con = new OracleConnection(connectionStringMTM2);
                    cmd.Connection = con;

                    con.Open();
                    cmd.CommandText = qry1;
                    OracleDataAdapter da = new OracleDataAdapter(cmd);
                    da.Fill(dt);
                    con.Close();
                }
                catch (Exception ex)
                {
                    //return Ret;                

                }
                return dt;
            }

        
    }
}